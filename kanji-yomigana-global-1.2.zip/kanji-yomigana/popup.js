// ── 탭 전환 ────────────────────────────────────────────────
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(`panel-${tab.dataset.tab}`).classList.add('active');
    if (tab.dataset.tab === 'history') loadHistory();
    if (tab.dataset.tab === 'focus')   loadFocus();
  });
});

// ── API 카드 선택 ───────────────────────────────────────────
const cardClaude = document.getElementById('card-claude');
const cardGemini = document.getElementById('card-gemini');

function applyApiMode(mode) {
  if (mode === 'gemini') {
    cardClaude.classList.remove('selected-claude');
    cardGemini.classList.add('selected-gemini');
  } else {
    cardGemini.classList.remove('selected-gemini');
    cardClaude.classList.add('selected-claude');
  }
}

[cardClaude, cardGemini].forEach(card => {
  card.addEventListener('click', (e) => {
    // 저장 버튼 클릭은 모드 전환 안 함
    if (e.target.classList.contains('btn-save') || e.target.classList.contains('key-input')) return;
    const mode = card.dataset.mode;
    chrome.storage.local.set({ apiMode: mode });
    applyApiMode(mode);
  });
});

// 초기 모드 로드
chrome.storage.local.get(['apiMode'], ({ apiMode }) => applyApiMode(apiMode || 'claude'));

// ── API 키 저장 ─────────────────────────────────────────────
function setupKey(inputId, btnId, statusId, storageKey, validator) {
  const input  = document.getElementById(inputId);
  const btn    = document.getElementById(btnId);
  const status = document.getElementById(statusId);

  chrome.storage.local.get([storageKey], (res) => {
    if (res[storageKey]) {
      input.value = res[storageKey];
      showStatus(status, 'Saved ✓', 'success');
    }
  });

  btn.addEventListener('click', (e) => {
    e.stopPropagation(); // 카드 클릭 전파 방지
    const val = input.value.trim();
    if (!val) { showStatus(status, 'Please enter a key', 'error'); return; }
    if (validator && !validator(val)) { showStatus(status, 'Invalid format', 'error'); return; }
    const obj = {}; obj[storageKey] = val;
    chrome.storage.local.set(obj, () => showStatus(status, 'Saved ✓', 'success'));
  });
}

setupKey('claude-key-input', 'save-claude-btn', 'claude-status', 'anthropicKey', v => v.startsWith('sk-ant-'));
setupKey('gemini-key-input', 'save-gemini-btn', 'gemini-status', 'geminiKey',    v => v.startsWith('AIza'));

// ── API 키 삭제 ─────────────────────────────────────────────
function setupKeyClear(btnId, inputId, statusId, storageKey) {
  document.getElementById(btnId).addEventListener('click', (e) => {
    e.stopPropagation();
    const input  = document.getElementById(inputId);
    const status = document.getElementById(statusId);
    input.value = '';
    const obj = {}; obj[storageKey] = '';
    chrome.storage.local.remove(storageKey, () => showStatus(status, 'Key removed', 'error'));
  });
}

setupKeyClear('clear-claude-btn', 'claude-key-input', 'claude-status', 'anthropicKey');
setupKeyClear('clear-gemini-btn', 'gemini-key-input', 'gemini-status', 'geminiKey');

function showStatus(el, msg, type) {
  el.textContent = msg; el.className = `status-msg ${type}`;
}

// ── 토글 ───────────────────────────────────────────────────
const toggleBtn   = document.getElementById('toggle-btn');
const toggleLabel = document.getElementById('toggle-label');

function applyToggle(enabled) {
  toggleBtn.classList.toggle('on', enabled);
  toggleLabel.textContent = enabled ? 'ON' : 'OFF';
}

chrome.storage.local.get(['kanjEnabled'], ({ kanjEnabled }) => applyToggle(kanjEnabled !== false));

toggleBtn.addEventListener('click', () => {
  const next = !toggleBtn.classList.contains('on');
  chrome.storage.local.set({ kanjEnabled: next });
  applyToggle(next);
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => chrome.tabs.sendMessage(tab.id, { action: 'setEnabled', enabled: next }).catch(() => {}));
  });
});

// ── 공통 유틸 ──────────────────────────────────────────────
function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function emptyState(icon, html) {
  return `<div class="empty-state"><span class="empty-kanji">${icon}</span><p>${html}</p></div>`;
}

// ── 집중암기 계산 ──────────────────────────────────────────
function computeFocus(kanjiHistory, kanjiClicks) {
  const cutoff = Date.now() - 7 * 24 * 60 * 60 * 1000;
  const freq   = {};
  const clicks = (kanjiClicks || []).filter(c => c.t > cutoff);

  if (clicks.length > 0) {
    clicks.forEach(c => {
      if (!freq[c.original]) freq[c.original] = { ...c, count: 0, lastSeen: 0 };
      freq[c.original].count++;
      if (c.t > freq[c.original].lastSeen) {
        freq[c.original].lastSeen = c.t;
        freq[c.original].yomigana = c.yomigana;
        freq[c.original].meaning  = c.meaning;
      }
    });
  } else {
    Object.values(kanjiHistory || {}).forEach(items =>
      items.forEach(item => {
        if ((item.timestamp || 0) < cutoff) return;
        if (!freq[item.original]) freq[item.original] = { ...item, count: 0, lastSeen: 0 };
        freq[item.original].count++;
        if ((item.timestamp || 0) > freq[item.original].lastSeen) {
          freq[item.original].lastSeen = item.timestamp;
          freq[item.original].yomigana = item.yomigana;
          freq[item.original].meaning  = item.meaning;
        }
      })
    );
  }

  return Object.values(freq)
    .filter(v => v.count >= 2)
    .sort((a, b) => b.count - a.count || b.lastSeen - a.lastSeen);
}

function updateFocusBadge() {
  chrome.storage.local.get(['kanjiHistory','kanjiClicks','focusDeleted'], ({ kanjiHistory, kanjiClicks, focusDeleted }) => {
    const deleted = new Set(focusDeleted || []);
    const n = computeFocus(kanjiHistory, kanjiClicks).filter(v => !deleted.has(v.original)).length;
    const badge = document.getElementById('focus-badge');
    badge.textContent = n; badge.style.display = n > 0 ? 'inline-block' : 'none';
  });
}

// ── 오늘의 한자 ────────────────────────────────────────────
function loadHistory() {
  const today = new Date().toDateString();
  const d = new Date();
  document.getElementById('today-badge').textContent = `${d.toLocaleDateString('en-US', {month:'short', day:'numeric'})}`;

  chrome.storage.local.get(['kanjiHistory'], ({ kanjiHistory }) => {
    const items   = (kanjiHistory || {})[today] || [];
    const countEl = document.getElementById('history-count');
    const listEl  = document.getElementById('history-list');

    countEl.textContent = items.length ? `${items.length} learned today` : '';

    if (!items.length) {
      listEl.innerHTML = emptyState('漢', 'No kanji looked up today.<br>Click any kanji on a Japanese page!');
      return;
    }

    listEl.innerHTML = items.map((item, idx) => `
      <div class="kanji-card">
        <div class="kc-yomigana">${escHtml(item.yomigana)}</div>
        <div class="kc-original">${escHtml(item.original)}</div>
        ${item.meaning ? `<div class="kc-meaning">${escHtml(item.meaning)}</div>` : ''}
        <button class="ki-del kc-del" data-idx="${idx}" title="삭제">✕</button>
      </div>`).join('');

    listEl.querySelectorAll('.kc-del').forEach(btn =>
      btn.addEventListener('click', e => {
        e.stopPropagation();
        deleteHistoryItem(today, parseInt(btn.dataset.idx));
      })
    );
  });
}

function deleteHistoryItem(dateKey, idx) {
  chrome.storage.local.get(['kanjiHistory'], ({ kanjiHistory }) => {
    const h = kanjiHistory || {};
    if (!h[dateKey]) return;
    h[dateKey].splice(idx, 1);
    if (!h[dateKey].length) delete h[dateKey];
    chrome.storage.local.set({ kanjiHistory: h }, () => { loadHistory(); updateFocusBadge(); });
  });
}

document.getElementById('clear-today-btn').addEventListener('click', () => {
  const today = new Date().toDateString();
  chrome.storage.local.get(['kanjiHistory'], ({ kanjiHistory }) => {
    const h = kanjiHistory || {};
    delete h[today];
    chrome.storage.local.set({ kanjiHistory: h }, () => { loadHistory(); updateFocusBadge(); });
  });
});

// ── 집중암기 ───────────────────────────────────────────────
function loadFocus() {
  chrome.storage.local.get(['kanjiHistory','kanjiClicks','focusDeleted'], ({ kanjiHistory, kanjiClicks, focusDeleted }) => {
    const deleted = new Set(focusDeleted || []);
    const items   = computeFocus(kanjiHistory, kanjiClicks).filter(v => !deleted.has(v.original));
    const badge   = document.getElementById('focus-badge');
    const countEl = document.getElementById('focus-count');
    const listEl  = document.getElementById('focus-list');

    badge.textContent = items.length; badge.style.display = items.length > 0 ? 'inline-block' : 'none';
    countEl.textContent = items.length ? `${items.length} entries · last 7 days` : '';

    if (!items.length) {
      listEl.innerHTML = emptyState('覚', 'No focus items yet.<br>Look up the same kanji 2+ times<br>and it will appear here automatically!');
      return;
    }

    listEl.innerHTML = items.map((item, idx) => {
      const medal = idx < 3 ? ['🥇','🥈','🥉'][idx] : `${idx+1}위`;
      return `<div class="kanji-item focus-item">
        <div class="ki-kanji">${escHtml(item.original)}</div>
        <div class="ki-info">
          <div class="ki-yomigana">${escHtml(item.yomigana)}</div>
          ${item.meaning ? `<div class="ki-meaning">${escHtml(item.meaning)}</div>` : ''}
        </div>
        <div class="ki-meta">
          <span class="ki-rank">${medal}</span>
          <span class="ki-count">${item.count}회</span>
        </div>
        <button class="ki-del" data-key="${escHtml(item.original)}" title="제거">✕</button>
      </div>`;
    }).join('');

    listEl.querySelectorAll('.ki-del').forEach(btn =>
      btn.addEventListener('click', e => {
        e.stopPropagation();
        chrome.storage.local.get(['focusDeleted'], ({ focusDeleted }) => {
          const list = [...new Set([...(focusDeleted || []), btn.dataset.key])];
          chrome.storage.local.set({ focusDeleted: list }, loadFocus);
        });
      })
    );
  });
}

document.getElementById('clear-focus-btn').addEventListener('click', () => {
  chrome.storage.local.get(['kanjiHistory','kanjiClicks','focusDeleted'], ({ kanjiHistory, kanjiClicks, focusDeleted }) => {
    const all     = computeFocus(kanjiHistory, kanjiClicks);
    const deleted = new Set([...(focusDeleted || []), ...all.map(v => v.original)]);
    chrome.storage.local.set({ focusDeleted: [...deleted] }, loadFocus);
  });
});

// ── Translation Language ───────────────────────────────────
const langSelect = document.getElementById('lang-select');

chrome.storage.local.get(['translationLang'], ({ translationLang }) => {
  if (translationLang) langSelect.value = translationLang;
});

langSelect.addEventListener('change', () => {
  chrome.storage.local.set({ translationLang: langSelect.value });
});

// ── Init ────────────────────────────────────────────────────
updateFocusBadge();

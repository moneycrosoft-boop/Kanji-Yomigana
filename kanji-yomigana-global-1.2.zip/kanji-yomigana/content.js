// ── 정규식 ──────────────────────────────────────────────────
const RE_KANJI = /[\u4e00-\u9faf\u3400-\u4dbf\u{20000}-\u{2a6df}\u{f900}-\u{faff}]/u;
// 히라가나/가타카나 (한자 옆 가나 포함 여부 판단용)
const RE_KANA  = /[\u3041-\u309f\u30a0-\u30ff]/u;

let tooltip      = null;
let isProcessing = false;
let currentWord  = null;
let isEnabled    = true; // 토글 상태

// ── 툴팁 DOM ────────────────────────────────────────────────
function ensureTooltip() {
  if (tooltip) return tooltip;
  tooltip = document.createElement('div');
  tooltip.id = 'kanji-yomigana-tooltip';
  tooltip.innerHTML = `
    <div class="kyt-inner">
      <div class="kyt-loading">
        <div class="kyt-spinner"></div>
        <span>Converting…</span>
      </div>
      <div class="kyt-content" style="display:none">
        <div class="kyt-yomigana"></div>
        <div class="kyt-original"></div>
        <div class="kyt-meaning"></div>
      </div>
      <button class="kyt-close" title="닫기">✕</button>
      <span class="kyt-api-badge"></span>
    </div>`;
  document.documentElement.appendChild(tooltip);
  tooltip.querySelector('.kyt-close').addEventListener('click', hideTooltip);
  return tooltip;
}

// 후리가나 HTML 생성
// 형식: (かくにん)しました  — 한자 부분을 괄호로 묶어서 요미가나 앞에 표시
// Claude 응답이 단어 전체의 요미가나만 주므로, 한자 런(run)을 찾아서 괄호 삽입
function buildFuriganaHTML(yomigana, original) {
  const esc = s => s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  const KANJI = /[一-龯㐀-䶿]/;

  // 한자가 없으면 요미가나만 표시
  if (!KANJI.test(original)) return esc(yomigana);

  // 원문을 한자런 / 가나런으로 분리
  // 예: "確認しました" → ["確認", "しました"]
  const chunks = [];
  let cur = '';
  let curIsKanji = null;
  for (const ch of original) {
    const isK = KANJI.test(ch);
    if (curIsKanji === null) curIsKanji = isK;
    if (isK !== curIsKanji) { chunks.push({ text: cur, isKanji: curIsKanji }); cur = ''; curIsKanji = isK; }
    cur += ch;
  }
  if (cur) chunks.push({ text: cur, isKanji: curIsKanji });

  // 한자런이 1개이고 가나런도 섞여있는 경우:
  // 요미가나 전체를 한자 부분 앞에 괄호로 표시하고 나머지 가나는 그대로
  // 예: 確認しました → (かくにん)しました
  // 한자런이 여러 개면 전체 요미가나를 괄호로
  const kanjiChunks = chunks.filter(c => c.isKanji);
  const kanaChunks  = chunks.filter(c => !c.isKanji);

  if (kanjiChunks.length === 0) return esc(yomigana);

  // 단순 전략: 뒤에 붙는 가나(활용어미 등)를 요미가나 끝에서 떼어냄
  // 예: 원문 "確認しました", 요미가나 "かくにんしました"
  //     → 뒤 가나 "しました"(3자)를 요미가나 끝 "しました"에서 대조
  // leading: 첫 chunk가 가나일 때만
  const leadingKana  = chunks[0].isKanji ? '' : chunks[0].text;
  // trailing: 마지막 chunk가 가나이고, 첫 chunk와 다른 chunk일 때만
  const lastChunk    = chunks[chunks.length - 1];
  const trailingKana = (!lastChunk.isKanji && chunks.length > 1 && lastChunk !== chunks[0])
    ? lastChunk.text : '';

  let furigana = yomigana;
  if (trailingKana && furigana.endsWith(trailingKana))
    furigana = furigana.slice(0, -trailingKana.length);
  if (leadingKana && furigana.startsWith(leadingKana))
    furigana = furigana.slice(leadingKana.length);

  let result = '';
  if (leadingKana) result += esc(leadingKana);
  result += '<span class="kyt-furi-group">'
          + '<span class="kyt-furi-kana">(' + esc(furigana) + ')</span>'
          + '</span>';
  if (trailingKana) result += esc(trailingKana);

  return result;
}

function placeTooltip(cx, cy) {
  const tip = ensureTooltip();
  const W = 290, H = 110, M = 14;
  let left = cx + M;
  let top  = cy - H / 2;
  if (left + W > window.innerWidth)  left = cx - W - M;
  if (left < 0)                      left = M;
  if (top  < 0)                      top  = M;
  if (top  + H > window.innerHeight) top  = window.innerHeight - H - M;
  tip.style.left = `${left + window.scrollX}px`;
  tip.style.top  = `${top  + window.scrollY}px`;
}

function showLoading(cx, cy) {
  const tip = ensureTooltip();
  tip.querySelector('.kyt-loading').style.display = 'flex';
  tip.querySelector('.kyt-content').style.display = 'none';
  // reset error state
  tip.querySelector('.kyt-loading').innerHTML =
    '<div class="kyt-spinner"></div><span>Converting…</span>';
  placeTooltip(cx, cy);
  tip.classList.add('kyt-visible');
}

function showResult(original, yomigana, meaning, apiLabel) {
  const tip = ensureTooltip();
  tip.querySelector('.kyt-loading').style.display = 'none';
  tip.querySelector('.kyt-content').style.display = 'block';
  // 요미가나: 크고 노랗게 (한자 원문은 괄호 안에)
  tip.querySelector('.kyt-yomigana').innerHTML = buildFuriganaHTML(yomigana, original);
  // 원문: 작게 아래에
  tip.querySelector('.kyt-original').textContent = original;
  tip.querySelector('.kyt-meaning').textContent  = meaning || '';
  // API 배지
  const badge = tip.querySelector('.kyt-api-badge');
  if (badge) badge.textContent = apiLabel || '';
}

function showError(msg) {
  const tip = ensureTooltip();
  tip.querySelector('.kyt-loading').style.display = 'flex';
  tip.querySelector('.kyt-loading').innerHTML =
    `<span style="color:#ff6b6b;font-size:12px">⚠ ${msg}</span>`;
  tip.querySelector('.kyt-content').style.display = 'none';
}

function hideTooltip() {
  if (tooltip) tooltip.classList.remove('kyt-visible');
  currentWord = null;
}

// ── 한자 단어 추출 ──────────────────────────────────────────
/**
 * 클릭 좌표(cx, cy)에서 가장 가까운 한자 포함 단어를 추출한다.
 *
 * 우선순위:
 * 1. 드래그 선택 텍스트
 * 2. caretRangeFromPoint → 텍스트 노드에서 단어 범위 확장
 * 3. e.target 요소의 전체 텍스트 fallback
 */
function extractWord(cx, cy) {
  // 1) caretRangeFromPoint 로 캐럿 위치 파악
  //    (드래그 선택 후 클릭 오동작 방지를 위해 selection은 사용 안 함)
  const range = document.caretRangeFromPoint
    ? document.caretRangeFromPoint(cx, cy)
    : (() => {
        if (!document.caretPositionFromPoint) return null;
        const pos = document.caretPositionFromPoint(cx, cy);
        if (!pos) return null;
        const r = document.createRange();
        r.setStart(pos.offsetNode, pos.offset);
        r.collapse(true);
        return r;
      })();

  if (!range) return null;

  const node = range.startContainer;
  if (!node || node.nodeType !== Node.TEXT_NODE) return null;

  const text   = node.textContent;
  const offset = range.startOffset;

  // 3) 클릭 좌표가 실제 글자 위인지 검증
  //    caretRangeFromPoint 는 글자 오른쪽 경계에 캐럿을 놓으므로
  //    offset 과 offset-1 양쪽 글자의 렉트를 모두 확인
  const TOLERANCE = 6;
  function isClickOnChar(off) {
    if (off < 0 || off >= text.length) return false;
    const cr = document.createRange();
    cr.setStart(node, off);
    cr.setEnd(node, off + 1);
    const rects = cr.getClientRects();
    if (!rects.length) return false;
    const r = rects[0];
    return cx >= r.left - TOLERANCE && cx <= r.right  + TOLERANCE &&
           cy >= r.top  - TOLERANCE && cy <= r.bottom + TOLERANCE;
  }
  // offset 또는 offset-1 중 하나라도 클릭 범위 안이면 통과
  if (!isClickOnChar(offset) && !isClickOnChar(offset - 1)) return null;

  // 4) 클릭 글자가 한자인지 확인 (한자 위만 동작)
  const chAt  = text[offset]     || '';
  const chPre = text[offset - 1] || '';
  const isKanjiAt  = RE_KANJI.test(chAt);
  const isKanjiPre = RE_KANJI.test(chPre);
  if (!isKanjiAt && !isKanjiPre) return null; // 한자가 아닌 곳 클릭 → 무시

  // 5) 클릭한 한자 런 경계 찾기
  let pos = isKanjiAt ? offset : offset - 1;
  if (pos < 0) pos = 0;

  let start = pos;
  while (start > 0 && RE_KANJI.test(text[start - 1])) start--;
  let end = pos;
  while (end < text.length - 1 && RE_KANJI.test(text[end + 1])) end++;
  end++;

  // 뒤 히라가나: 다음 한자 직전까지
  let e2 = end;
  while (e2 < text.length && RE_KANA.test(text[e2]) && !RE_KANJI.test(text[e2])) { e2++; }

  // 클릭한 단어 (화면 표시 + target)
  const target = text.slice(start, e2).trim();
  if (!target || !RE_KANJI.test(target)) return null;

  // 6) 문맥: 클릭한 단어 앞의 한자+가나 런을 최대 10글자 포함
  //    예: "添削の進め方" 에서 "方" 클릭 시 앞 문맥 "進め" 포함 → "進め方"
  let ctxStart = start;
  // 앞 가나 (조사/어미)
  while (ctxStart > 0 && RE_KANA.test(text[ctxStart - 1])) ctxStart--;
  // 앞 한자런
  while (ctxStart > 0 && RE_KANJI.test(text[ctxStart - 1])) ctxStart--;
  // 앞 가나 한번 더 (한자+가나+한자 패턴 대응)
  while (ctxStart > 0 && RE_KANA.test(text[ctxStart - 1])) ctxStart--;

  const context = text.slice(ctxStart, e2).trim().slice(0, 40);

  return { target, context };
}

// ── Background 통신 ─────────────────────────────────────────
function requestYomigana(text, context) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action: 'getYomigana', text, context }, (res) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else if (!res) {
        reject(new Error('응답 없음 — background script를 확인하세요'));
      } else if (res.error) {
        reject(new Error(res.error));
      } else {
        resolve(res);
      }
    });
  });
}

// ── 히스토리 저장 ────────────────────────────────────────────
function saveToHistory(original, yomigana, meaning) {
  const today = new Date().toDateString();
  const now   = Date.now();
  chrome.storage.local.get(['kanjiHistory', 'kanjiClicks'], (result) => {
    const history = result.kanjiHistory || {};
    if (!history[today]) history[today] = [];
    const idx = history[today].findIndex(i => i.original === original);
    const entry = { original, yomigana, meaning, timestamp: now };
    if (idx >= 0) { history[today].splice(idx, 1); }
    history[today].unshift(entry);
    if (history[today].length > 200) history[today].length = 200;

    const cutoff = now - 7 * 24 * 60 * 60 * 1000;
    const clicks = (result.kanjiClicks || []).filter(c => c.t > cutoff);
    clicks.push({ original, yomigana, meaning, t: now });
    chrome.storage.local.set({ kanjiHistory: history, kanjiClicks: clicks });
  });
}

// 인터랙티브 요소인지 확인 (버튼, 링크, 입력 등)
function isInteractive(el) {
  if (!el) return false;
  const tag = el.tagName;
  if (['BUTTON','A','INPUT','SELECT','TEXTAREA','LABEL','SUMMARY'].includes(tag)) return true;
  if (el.getAttribute('role') === 'button') return true;
  if (el.getAttribute('onclick')) return true;
  if (el.style && (el.style.cursor === 'pointer')) return true;
  // 부모 3단계까지 확인 (아이콘이 span으로 감싸진 버튼 등)
  let p = el.parentElement;
  for (let i = 0; i < 3 && p; i++, p = p.parentElement) {
    const pt = p.tagName;
    if (['BUTTON','A'].includes(pt)) return true;
    if (p.getAttribute('role') === 'button') return true;
  }
  return false;
}

// ── 클릭 핸들러 ─────────────────────────────────────────────
document.addEventListener('click', async (e) => {
  // 툴팁 내부 클릭 무시
  if (tooltip && tooltip.contains(e.target)) return;

  // 토글 꺼져있으면 툴팁만 닫고 종료
  if (!isEnabled) { hideTooltip(); return; }

  // 버튼, 링크 등 인터랙티브 요소 클릭 무시
  if (isInteractive(e.target)) return;

  // 모달/오버레이 감지: pointer-events가 none인 요소 위 클릭은 무시
  {
    const computed = window.getComputedStyle(e.target);
    if (computed.pointerEvents === 'none' || computed.visibility === 'hidden') {
      hideTooltip();
      return;
    }
  }

  // API 키 확인
  let hasKey;
  try {
    const res = await new Promise(r => chrome.storage.local.get(['anthropicKey', 'geminiKey'], r));
    hasKey = !!(res.anthropicKey || res.geminiKey);
  } catch (_) { return; }

  if (!hasKey) {
    // 선택된 모드 확인해서 해당 API 키를 넣어달라고 안내
    const { apiMode } = await new Promise(r => chrome.storage.local.get(['apiMode'], r));
    const modeName = (apiMode === 'gemini') ? 'Gemini' : 'Claude';
    showLoading(e.clientX, e.clientY);
    showError(`${modeName} API key not set — open the extension popup → Settings`);
    return;
  }

  const extracted = extractWord(e.clientX, e.clientY);

  if (!extracted) {
    hideTooltip();
    return;
  }

  const { target, context } = extracted;

  // 같은 단어 재클릭 → 닫기
  if (currentWord === target && tooltip && tooltip.classList.contains('kyt-visible')) {
    hideTooltip();
    return;
  }

  // 이미 처리 중이면 무시
  if (isProcessing) return;

  currentWord  = target;
  isProcessing = true;
  showLoading(e.clientX, e.clientY);

  // 10초 안전 타임아웃 — isProcessing 고착 방지
  const safetyTimer = setTimeout(() => { isProcessing = false; }, 10000);

  try {
    const result = await requestYomigana(target, context);
    // original 표시는 AI 응답값 대신 실제 클릭한 target 사용
    // (AI가 original 필드를 다르게 반환하는 경우 대비)
    showResult(target, result.yomigana, result.meaning, result.apiLabel);
    saveToHistory(target, result.yomigana, result.meaning);
  } catch (err) {
    showError(err.message || '알 수 없는 오류');
  } finally {
    clearTimeout(safetyTimer);
    isProcessing = false;
  }
}, true);

// ESC로 닫기
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') hideTooltip();
});

// 팝업에서 토글 메시지 수신
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === 'setEnabled') {
    isEnabled = msg.enabled;
    if (!isEnabled) hideTooltip();
  }
});

// 초기 토글 상태 동기화
chrome.storage.local.get(['kanjEnabled'], ({ kanjEnabled }) => {
  isEnabled = kanjEnabled !== false; // 기본값 true
});

// Background service worker — Claude / Gemini 선택 지원

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getYomigana') {
    dispatch(request.text, request.context)
      .then(result => sendResponse(result))
      .catch(err   => sendResponse({ error: err.message || String(err) }));
    return true;
  }
});

// ── 분기 ────────────────────────────────────────────────────
async function dispatch(text, context) {
  const stored = await chrome.storage.local.get(['apiMode', 'anthropicKey', 'geminiKey', 'translationLang']);
  const mode   = stored.apiMode || 'claude';
  const lang   = stored.translationLang || 'English';
  if (mode === 'gemini') {
    if (!stored.geminiKey) throw new Error('Gemini API key not set. Please add it in the extension popup.');
    return queryGemini(text, context, stored.geminiKey, lang);
  } else {
    if (!stored.anthropicKey) throw new Error('Claude API key not set. Please add it in the extension popup.');
    return queryClaude(text, context, stored.anthropicKey, lang);
  }
}

// ── JSON 추출 공통 ────────────────────────────────────────────
function extractJSON(raw) {
  // 마크다운 코드블록 제거 (```json ... ``` 또는 ``` ... ```)
  const stripped = raw.replace(/```(?:json)?/gi, '').trim();
  const s = stripped.indexOf('{');
  const e = stripped.lastIndexOf('}');
  return (s !== -1 && e > s) ? stripped.slice(s, e + 1) : stripped;
}

// ── Claude 프롬프트 ────────────────────────────────────────────
function claudePrompt(text, context, lang = "English") {
  const hasContext = context && context !== text && context.length > text.length;
  if (hasContext) {
    return `Determine the reading of the target Japanese word using context.

Full context: 「${context}」
Target: 「${text}」

Rules:
- Write ONLY the hiragana reading of 「${text}」 in the yomigana field.
- Do NOT include readings of surrounding characters.
- Example: context「進め方」, target「方」→ yomigana: 「かた」only
- Example: context「お客様の方」, target「方」→ yomigana: 「ほう」only

Respond in JSON only (no markdown, no explanation):
{"original":"${text}","yomigana":"hiragana reading of target only","meaning":"translation in ${lang} (max 10 words)"}`;
  }
  return `Provide the hiragana reading (よみがな) and ${lang} meaning of the Japanese text below.

Input: ${text}

Respond in JSON only (no markdown, no explanation):
{"original":"${text}","yomigana":"히라가나로 전체 읽기","meaning":"translation in ${lang} (max 10 words)"}`;
}

// ── Gemini 프롬프트 (few-shot) ────────────────────────────────
function geminiPrompt(text, context, lang = "English") {
  const hasContext = context && context !== text && context.length > text.length;
  if (hasContext) {
    return `Output ONLY a JSON object. No markdown, no explanation.
Rules: yomigana = hiragana reading of target only. meaning = ${lang} translation (max 5 words).

{"original":"...","yomigana":"...","meaning":"..."}

context[${context}] target[${text}]`;
  }
  return `Output ONLY a JSON object. No markdown, no explanation.
Rules: yomigana = hiragana reading. meaning = ${lang} translation (max 5 words).

{"original":"...","yomigana":"...","meaning":"..."}

Input: ${text}`;
}

// ── 응답 파싱 공통 ────────────────────────────────────────────
function parseResponse(raw, text) {
  const cleaned = extractJSON(raw);
  let parsed;
  try { parsed = JSON.parse(cleaned); }
  catch (_) { return { original: text, yomigana: raw.slice(0, 40), meaning: '' }; }
  return {
    original: parsed.original || text,
    yomigana: parsed.yomigana || '?',
    meaning:  parsed.meaning  || ''
  };
}

// ── Claude (Haiku) ────────────────────────────────────────────
async function queryClaude(text, context, apiKey, lang = "English") {
  const prompt = claudePrompt(text, context, lang);
  let res;
  try {
    res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 200,
        messages: [{ role: 'user', content: prompt }]
      })
    });
  } catch (e) { throw new Error('Network error: ' + e.message); }

  if (!res.ok) {
    let msg = `Claude API error (${res.status})`;
    try { const b = await res.json(); msg = b.error?.message || msg; } catch (_) {}
    throw new Error(msg);
  }
  const data = await res.json();
  const raw  = (data.content?.[0]?.text || '').trim();
  return { ...parseResponse(raw, text), apiLabel: 'Claude' };
}

// ── Gemini 2.5 Flash ─────────────────────────────────────────
async function queryGemini(text, context, apiKey, lang = "English") {
  const prompt = geminiPrompt(text, context, lang);
  const MAX_RETRIES = 3;
  const RETRY_DELAYS = [1000, 2000, 4000]; // 1초, 2초, 4초

  for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
    // 재시도 대기
    if (attempt > 0) {
      await new Promise(r => setTimeout(r, RETRY_DELAYS[attempt - 1]));
    }

    let res;
    try {
      res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: { temperature: 0, maxOutputTokens: 1024, thinkingConfig: { thinkingBudget: 0 } }
          })
        }
      );
    } catch (e) { throw new Error('Network error: ' + e.message); }

    // 성공
    if (res.ok) {
      const data = await res.json();
      const raw  = (data.candidates?.[0]?.content?.parts?.[0]?.text || '').trim();
      console.log('[Gemini RAW]', JSON.stringify(raw));
      return { ...parseResponse(raw, text), apiLabel: 'Gemini' };
    }

    // 429(과부하) / 503(일시적 오류) → 재시도
    if ((res.status === 429 || res.status === 503) && attempt < MAX_RETRIES - 1) {
      console.log(`[Gemini] ${res.status} error, retrying (${attempt + 1})...`);
      continue;
    }

    // 그 외 오류는 즉시 throw
    let msg = `Gemini API error (${res.status})`;
    try { const b = await res.json(); msg = b.error?.message || msg; } catch (_) {}
    throw new Error(msg);
  }

  throw new Error('Gemini server is busy. Please try again later.');
}
